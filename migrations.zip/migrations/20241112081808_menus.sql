CREATE TABLE IF NOT EXISTS menus (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sort INT,
    menu_name TEXT,
    icon TEXT,
    status VARCHAR(10) CHECK (status IN ('active', 'in_active')),
    created_at TIMESTAMP,
    created_by CHAR(36),
    updated_at TIMESTAMP,
    updated_by CHAR(36)
);