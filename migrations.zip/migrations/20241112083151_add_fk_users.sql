ALTER TABLE users
ADD CONSTRAINT fk_title_id
    FOREIGN KEY (title_id) REFERENCES m_titles(id)
    ON DELETE SET NULL,
ADD CONSTRAINT fk_department_id
    FOREIGN KEY (department_id) REFERENCES m_departments(id)
    ON DELETE SET NULL;
