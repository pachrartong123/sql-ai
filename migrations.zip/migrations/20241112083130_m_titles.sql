CREATE TABLE IF NOT EXISTS m_titles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sort INT,
    title_name_th TEXT,
    title_short_name_th TEXT,
    title_name_en TEXT,
    title_short_name_en TEXT,
    status VARCHAR(10) CHECK (status IN ('active', 'in_active')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP,
    created_by CHAR(36),
    updated_by CHAR(36)
);