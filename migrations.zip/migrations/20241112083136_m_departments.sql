CREATE TABLE IF NOT EXISTS m_departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name_th TEXT,
    name_en TEXT,
    status VARCHAR(10) CHECK (status IN ('active', 'in_active')),
    sort INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP
);
