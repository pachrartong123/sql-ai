CREATE TABLE IF NOT EXISTS permissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    menu_id UUID NOT NULL,
    role_id UUID NOT NULL,
    action VARCHAR(20) CHECK (action IN ('can_view_all', 'can_edit_all', 'can_delete_all', 'can_view_self', 'can_edit_self', 'can_delete_self')),
    status VARCHAR(10) CHECK (status IN ('active', 'in_active')),
    created_at TIMESTAMP,
    created_by CHAR(36),
    updated_at TIMESTAMP,
    updated_by CHAR(36),
    CONSTRAINT fk_menu
        FOREIGN KEY (menu_id) REFERENCES menus(id)
        ON DELETE CASCADE,
    CONSTRAINT fk_role
        FOREIGN KEY (role_id) REFERENCES roles(id)
        ON DELETE CASCADE
);