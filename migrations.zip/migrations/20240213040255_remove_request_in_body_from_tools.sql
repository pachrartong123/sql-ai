ALTER TABLE tools
DROP COLUMN request_in_body;
